<?php
# 資料庫設定
$hostname = 'sql200.infinityfree.com';
$database = '9if0_39080853_1112213080'; // 假設你的電影資料表是放在這個資料庫中
$dbuser = 'if0_39080853';
$dbpass = '99TKYJfhW7c6';

# 首頁設定
$main = 'manage_movies.php'; // 更新為你的電影管理頁面
?>
